# Radiant Spark Global — Production Build & Live SparkDeals Package

## Option A: Deploy Full Repository with Automated 15-Minute Deal Refresh (Recommended)
Use `radiant-spark-full-codebase.zip`:
1. Unzip and push all files (including `.github/workflows/pages.yml`) to the `main` branch of `RadiantSparkLLC/radiantspark-site`.
2. In GitHub **Settings -> Pages**, set **Source** to **GitHub Actions**.
3. The site builds and automatically refreshes `deals-feed.json` every 15 minutes with verified live & Black Friday deals.

## Option B: Static Branch Upload
Use `radiantspark-final.zip`:
1. Unzip all compiled files (`index.html`, `sparkdeals.html`, `deals-feed.json`, `assets/`, `CNAME`, `.nojekyll`) to the `main` branch root.
2. In GitHub **Settings -> Pages**, set **Source** to **Deploy from a branch -> main / (root)**.
