/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface CurrencyConfig {
  code: 'USD' | 'INR' | 'EUR' | 'GBP' | 'AED' | 'CAD' | 'AUD' | 'SGD' | 'JPY';
  symbol: string;
  label: string;
  rateFromUsd: number;
  zeroDecimal?: boolean;
  localMethodsNote: string;
}

export const SUPPORTED_CURRENCIES: CurrencyConfig[] = [
  {
    code: 'USD',
    symbol: '$',
    label: 'USD ($ United States)',
    rateFromUsd: 1,
    localMethodsNote: 'Visa, Mastercard, Amex, Discover, Apple Pay, Google Pay, Link',
  },
  {
    code: 'INR',
    symbol: '₹',
    label: 'INR (₹ India)',
    rateFromUsd: 92.68,
    localMethodsNote: 'International & Indian Visa / Mastercard / Amex / RuPay Cards & Apple Pay',
  },
  {
    code: 'EUR',
    symbol: '€',
    label: 'EUR (€ Europe)',
    rateFromUsd: 0.91,
    localMethodsNote: 'Visa, Mastercard, Amex, Apple Pay, Google Pay & EU Cards',
  },
  {
    code: 'GBP',
    symbol: '£',
    label: 'GBP (£ United Kingdom)',
    rateFromUsd: 0.76,
    localMethodsNote: 'UK Visa, Mastercard, Amex, Apple Pay & Google Pay',
  },
  {
    code: 'AED',
    symbol: 'AED ',
    label: 'AED (UAE Dirham)',
    rateFromUsd: 3.67,
    localMethodsNote: 'UAE Visa, Mastercard, Amex, Apple Pay & Google Pay',
  },
  {
    code: 'CAD',
    symbol: 'CA$',
    label: 'CAD ($ Canada)',
    rateFromUsd: 1.43,
    localMethodsNote: 'Canadian Visa, Mastercard, Amex, Apple Pay & Google Pay',
  },
  {
    code: 'AUD',
    symbol: 'A$',
    label: 'AUD ($ Australia)',
    rateFromUsd: 1.50,
    localMethodsNote: 'Australian Visa, Mastercard, Amex, Apple Pay & Google Pay',
  },
  {
    code: 'SGD',
    symbol: 'S$',
    label: 'SGD ($ Singapore)',
    rateFromUsd: 1.29,
    localMethodsNote: 'Singapore Visa, Mastercard, Amex, Apple Pay & Google Pay',
  },
  {
    code: 'JPY',
    symbol: '¥',
    label: 'JPY (¥ Japan)',
    rateFromUsd: 158.6,
    zeroDecimal: true,
    localMethodsNote: 'JCB, Visa, Mastercard, Amex, Apple Pay & Google Pay',
  },
];

export interface LifestylePlanTier {
  id: string;
  name: string;
  priceUsd: number;
  interval: 'month' | 'year' | 'one_time';
  badge: string;
  description: string;
  features: string[];
}

export const LIFESTYLE_PLAN_TIERS: LifestylePlanTier[] = [
  {
    id: 'lifestyle_spark_monthly',
    name: 'Lifestyle Spark Pro Monthly',
    priceUsd: 9.99,
    interval: 'month',
    badge: 'Most Flexible',
    description: 'Unlimited real-time diet plans, step-by-step recipe prep, workout timers, and cloud progress sync.',
    features: [
      'Custom calorie & macro meal matrix',
      'Full food-making recipes & ingredient lists',
      'Guided HIIT & low-impact weight-loss workouts',
      'Saved login profile across web & Lifestyle Spark app',
    ],
  },
  {
    id: 'lifestyle_spark_annual',
    name: 'Lifestyle Spark Pro Annual',
    priceUsd: 149.99,
    interval: 'year',
    badge: 'Full Year Access',
    description: 'Full year of continuous nutrition adjustments, recipe library updates, and weight tracking.',
    features: [
      'All Lifestyle Spark Pro Monthly features for 12 months',
      'Priority AI Coach custom meal swaps',
      'Multi-cuisine Indian, Mediterranean & Keto plans',
      'Direct Stripe receipt & instant access activation',
    ],
  },
  {
    id: 'lifestyle_spark_90day',
    name: 'Lifestyle Spark 90-Day Pass',
    priceUsd: 49.99,
    interval: 'one_time',
    badge: 'One-Time Card Payment',
    description: 'Single one-time payment for a structured 12-week fat-loss meal & training roadmap with no recurring renewal.',
    features: [
      'Single non-recurring global card payment',
      '12-week progressive workout & meal schedule',
      'WhatsApp meal summary export',
      'Full Lifestyle Spark Mobile PWA access',
    ],
  },
];

export interface RecipeGuide {
  id: string;
  title: string;
  mealSlot: 'Breakfast' | 'Lunch' | 'Dinner' | 'Snack';
  dietStyle: 'high_protein' | 'vegetarian_sattvik' | 'vegan_organic' | 'keto_lowcarb';
  prepMinutes: number;
  cookMinutes: number;
  calories: number;
  proteinGrams: number;
  carbsGrams: number;
  fatGrams: number;
  ingredients: string[];
  steps: string[];
  chefTip: string;
}

export const LIFESPARK_RECIPES: RecipeGuide[] = [
  {
    id: 'rec-herb-salmon-quinoa',
    title: 'Lemon Herb Seared Salmon & Quinoa Power Bowl',
    mealSlot: 'Lunch',
    dietStyle: 'high_protein',
    prepMinutes: 8,
    cookMinutes: 14,
    calories: 465,
    proteinGrams: 39,
    carbsGrams: 34,
    fatGrams: 18,
    ingredients: [
      '150g wild salmon fillet (or extra-firm organic tofu / chicken breast)',
      '1/2 cup cooked tri-color quinoa',
      '1 cup fresh baby spinach & cherry tomatoes',
      '1/4 sliced ripe avocado',
      '1 tsp olive oil, 1 tbsp lemon juice, minced garlic, dill & sea salt',
    ],
    steps: [
      'Pat salmon dry, rub with olive oil, minced garlic, lemon zest, and pepper.',
      'Sear skin-side down in a hot non-stick skillet for 4 minutes, flip and cook 3 more minutes.',
      'Rinse quinoa and fluff with warm vegetable broth and chopped fresh herbs.',
      'Assemble spinach, halved cherry tomatoes, quinoa, avocado, and seared fillet; drizzle remaining lemon juice.',
    ],
    chefTip: 'Prep triple quinoa batches on Sunday so weekday bowls take under 10 minutes.',
  },
  {
    id: 'rec-moong-chilla-paneer',
    title: 'High-Protein Moong Dal Chilla with Spiced Paneer',
    mealSlot: 'Breakfast',
    dietStyle: 'vegetarian_sattvik',
    prepMinutes: 10,
    cookMinutes: 10,
    calories: 340,
    proteinGrams: 24,
    carbsGrams: 32,
    fatGrams: 11,
    ingredients: [
      '1/2 cup soaked yellow moong dal (split mung lentils)',
      '60g grated low-fat fresh paneer',
      '1 tsp grated ginger, chopped coriander, cumin seeds & pinch of turmeric',
      '1 tsp cold-pressed ghee or olive oil',
    ],
    steps: [
      'Blend soaked moong dal with ginger, cumin, turmeric, and a splash of water into a smooth crepe batter.',
      'Warm a lightly greased cast-iron tawa on medium heat and pour 1 ladle of batter outward in a circle.',
      'Scatter grated paneer, coriander, and cracked pepper across one half once edges lift cleanly.',
      'Fold into a crisp half-moon and serve hot with fresh mint-coriander chutney.',
    ],
    chefTip: 'Adding 1 tbsp oat flour keeps the batter crisp without extra oil.',
  },
  {
    id: 'rec-chickpea-tahini-bowl',
    title: 'Roasted Cumin Chickpea & Greens Detox Bowl',
    mealSlot: 'Lunch',
    dietStyle: 'vegan_organic',
    prepMinutes: 7,
    cookMinutes: 18,
    calories: 410,
    proteinGrams: 19,
    carbsGrams: 46,
    fatGrams: 15,
    ingredients: [
      '1 cup drained chickpeas',
      '1.5 cups kale or arugula + diced cucumber',
      '1 tbsp tahini whisked with 1 tbsp lemon juice & warm water',
      '1/2 tsp cumin, smoked paprika, garlic powder, sea salt',
    ],
    steps: [
      'Toss chickpeas in cumin, smoked paprika, and 1 tsp olive oil; roast at 200°C / 400°F for 18 minutes until crisp.',
      'Massage chopped greens with a squeeze of lemon juice for 30 seconds to soften fibers.',
      'Whisk tahini, lemon, warm water, and garlic into a creamy oil-light dressing.',
      'Layer greens, cucumber, warm spiced chickpeas, and drizzle dressing right before eating.',
    ],
    chefTip: 'Pat chickpeas thoroughly dry with a clean towel before roasting for maximum crunch.',
  },
  {
    id: 'rec-avocado-egg-skillet',
    title: 'Spinach, Walnut & Herb Omelet Skillet',
    mealSlot: 'Breakfast',
    dietStyle: 'keto_lowcarb',
    prepMinutes: 5,
    cookMinutes: 6,
    calories: 325,
    proteinGrams: 22,
    carbsGrams: 6,
    fatGrams: 24,
    ingredients: [
      '2 whole pasture eggs + 2 extra egg whites',
      '1 cup baby spinach & 4 halved cherry tomatoes',
      '1/4 diced avocado & 4 crushed walnut halves',
      '1 tsp butter or avocado oil, black pepper, parsley',
    ],
    steps: [
      'Whisk eggs and egg whites briskly with a pinch of sea salt and black pepper.',
      'Saute spinach in a warm skillet for 45 seconds until just wilted.',
      'Pour in beaten eggs, tilt pan gently until nearly set, fold in half.',
      'Top with diced avocado and crushed walnuts for sustained morning satiety.',
    ],
    chefTip: 'Pull off heat 20 seconds early so carryover warmth keeps the omelet tender.',
  },
  {
    id: 'rec-lentil-asparagus-soup',
    title: 'Light Ginger-Turmeric Lentil & Asparagus Soup',
    mealSlot: 'Dinner',
    dietStyle: 'high_protein',
    prepMinutes: 8,
    cookMinutes: 18,
    calories: 315,
    proteinGrams: 21,
    carbsGrams: 38,
    fatGrams: 7,
    ingredients: [
      '1/2 cup red lentils (rinsed)',
      '6 spears trimmed asparagus cut into 1-inch bites',
      '2 cups low-sodium vegetable broth',
      '1 tsp grated ginger, 1 clove garlic, 1/2 tsp turmeric & squeeze of lime',
    ],
    steps: [
      'Simmer garlic, ginger, and turmeric in broth for 2 minutes until aromatic.',
      'Add rinsed red lentils, cover, and simmer gently for 14 minutes until velvety.',
      'Drop in chopped asparagus for the final 3 minutes so stems stay bright green and crisp-tender.',
      'Finish with fresh lime juice and cracked pepper for an easy-to-digest evening dinner.',
    ],
    chefTip: 'Keeping dinner below 350 kcal helps improve overnight digestion and sleep quality.',
  },
  {
    id: 'rec-roasted-makhana-mint',
    title: 'Cumin-Chili Roasted Makhana (Fox Nuts) & Green Juice',
    mealSlot: 'Snack',
    dietStyle: 'vegetarian_sattvik',
    prepMinutes: 2,
    cookMinutes: 6,
    calories: 165,
    proteinGrams: 6,
    carbsGrams: 22,
    fatGrams: 5,
    ingredients: [
      '1.5 cups raw fox nuts (makhana)',
      '1/2 tsp cold-pressed ghee or coconut oil',
      'Pinch of chaat masala, roasted cumin, and Himalayan pink salt',
      'Paired with cucumber-mint-lemon infused water',
    ],
    steps: [
      'Dry-warm skillet on low heat, add 1/2 tsp ghee and toss fox nuts continuously for 5–6 minutes.',
      'Test crispness by crushing one between fingers—it should snap cleanly.',
      'Remove from heat immediately and dust with cumin and pink salt while warm.',
    ],
    chefTip: 'Portion into 1.5-cup jars so afternoon cravings never derail calorie deficit.',
  },
];

export interface WorkoutProgram {
  id: string;
  title: string;
  level: 'Beginner' | 'Intermediate' | 'Low Impact';
  durationMinutes: number;
  metValue: number;
  focusArea: string;
  exercises: {
    name: string;
    durationSec: number;
    repsOrRest: string;
    formCue: string;
  }[];
}

export const LIFESPARK_WORKOUTS: WorkoutProgram[] = [
  {
    id: 'wo-morning-fatburn',
    title: '20-Min Morning Metabolic HIIT Burner',
    level: 'Intermediate',
    durationMinutes: 20,
    metValue: 8.0,
    focusArea: 'Full-Body Fat Loss & Metabolic Boost',
    exercises: [
      {
        name: 'Warmup March & Arm Circles',
        durationSec: 120,
        repsOrRest: 'Continuous',
        formCue: 'Elevate heart rate gradually while opening chest and shoulders.',
      },
      {
        name: 'Bodyweight Squat to Reach',
        durationSec: 45,
        repsOrRest: '45s work / 15s rest',
        formCue: 'Sit hips back over heels, keep chest lifted and knees tracking over toes.',
      },
      {
        name: 'Incline or Floor Mountain Climbers',
        durationSec: 45,
        repsOrRest: '45s work / 15s rest',
        formCue: 'Brace core tightly so hips stay level without bouncing.',
      },
      {
        name: 'Reverse Alternating Lunges',
        durationSec: 45,
        repsOrRest: '45s work / 15s rest',
        formCue: 'Drive cleanly through the front heel to stand tall.',
      },
      {
        name: 'Fast Shadow Boxing or Jumping Jacks',
        durationSec: 45,
        repsOrRest: '45s work / 15s rest',
        formCue: 'Light balls of feet, fast rhythmic breathing.',
      },
    ],
  },
  {
    id: 'wo-low-impact-walk',
    title: '25-Min Joint-Friendly Walk & Core Tone',
    level: 'Low Impact',
    durationMinutes: 25,
    metValue: 4.8,
    focusArea: 'Knee-Safe Calorie Burn & Waistline Core',
    exercises: [
      {
        name: 'Brisk Indoor Pace March',
        durationSec: 180,
        repsOrRest: '3 min steady',
        formCue: 'Pump arms at 90 degrees to engage upper back and raise calorie output.',
      },
      {
        name: 'Standing Knee-to-Elbow Cross Crunch',
        durationSec: 60,
        repsOrRest: '60s controlled',
        formCue: 'Exhale on every twist and contract obliques cleanly without straining neck.',
      },
      {
        name: 'Step-Touch Side Shuffles',
        durationSec: 60,
        repsOrRest: '60s steady',
        formCue: 'Stay slightly bent at knees for glute engagement with zero jumping.',
      },
      {
        name: 'Wall Push-Ups + Glute Bridges',
        durationSec: 90,
        repsOrRest: '15 reps each',
        formCue: 'Squeeze glutes at the top for 2 seconds before lowering slowly.',
      },
    ],
  },
  {
    id: 'wo-evening-mobility',
    title: '15-Min Evening Fat-Burn Flow & Deep Stretch',
    level: 'Beginner',
    durationMinutes: 15,
    metValue: 3.5,
    focusArea: 'Cortisol Recovery, Posture & Flexibility',
    exercises: [
      {
        name: 'Sun Salutation Half-Flows',
        durationSec: 180,
        repsOrRest: '5 slow rounds',
        formCue: 'Match movement to deep 4-second nasal inhales and exhales.',
      },
      {
        name: 'Forearm Plank Hold',
        durationSec: 45,
        repsOrRest: '3x 30–45s',
        formCue: 'Press forearms down and lengthen spine from crown to heels.',
      },
      {
        name: 'Supine Twist & Hip Opener',
        durationSec: 120,
        repsOrRest: '60s per side',
        formCue: 'Keep both shoulder blades relaxed on the mat to lower evening stress.',
      },
    ],
  },
];

export function estimateWorkoutCalories(metValue: number, weightKg: number, durationMinutes: number) {
  const safeWeight = Number.isFinite(weightKg) && weightKg > 30 && weightKg < 250 ? weightKg : 72;
  return Math.round(((metValue * 3.5 * safeWeight) / 200) * durationMinutes);
}

export function formatLocalizedCurrency(
  amountUsd: number,
  currencyCode: CurrencyConfig['code'],
  liveFxRates?: Record<string, number>
) {
  const cfg = SUPPORTED_CURRENCIES.find((c) => c.code === currencyCode) || SUPPORTED_CURRENCIES[0];
  const liveRate = liveFxRates && typeof liveFxRates[currencyCode] === 'number' && liveFxRates[currencyCode] > 0
    ? liveFxRates[currencyCode]
    : cfg.rateFromUsd;
  const converted = amountUsd * liveRate;
  if (cfg.zeroDecimal) {
    return `${cfg.symbol}${Math.round(converted).toLocaleString('en-US')}`;
  }
  return `${cfg.symbol}${converted.toLocaleString('en-US', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })}`;
}
