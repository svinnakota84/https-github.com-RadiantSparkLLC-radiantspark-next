/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { AiEmployee, SparkDrinkOrder } from '../types';

export const AI_EMPLOYEES: AiEmployee[] = [
  {
    id: 'emp-1',
    name: 'Maya Chen',
    role: 'Chief AI Operations Orchestrator (US & India)',
    department: 'Executive Operations & Cross-Border Governance',
    avatar: '👩‍💼',
    status: 'active',
    currentTask: 'Coordinating multi-agent US operations (Radiant Spark LLC) & India fulfillment orchestration',
    tasksCompleted: 0,
    accuracy: 'Server-Verified',
    skills: [
      'US & India Multi-Agent Orchestration',
      'Amazon.com / Walmart / Best Buy Attribution',
      'FTC & India Regulatory Balancing',
      'Real-Time Stock & Tax Checkpoints',
    ],
    connectedUpstream: ['David Sterling', 'Ananya Iyer', 'Kavya Nair'],
    connectedDownstream: ['Arjun Reddy', 'Sarah Jenkins', 'Rajesh Varma', 'Kavya Nair'],
    handshakeProtocol: 'GLOBAL_ORCHESTRATION_SYNC',
    businessValue:
      'Coordinates all 11 US & India agents sequentially, issues autonomous self-healing audits, and reconciles live USD & INR company revenue.',
    systemPrompt:
      'You are Maya Chen, Chief AI Operations Orchestrator for Radiant Spark Global. You supervise 10 specialist AI agents across Radiant Spark LLC (United States) and RDNT Sparkle Industries LLP (India), coordinating US merchant affiliate monetization (Amazon.com, Walmart, Best Buy, Target, eBay), Lifestyle Spark Stripe subscriptions, IT consulting, GST compliance, and cold-chain dispatch.',
  },
  {
    id: 'emp-2',
    name: 'Arjun Reddy',
    role: 'Head of US/India B2B & Vendor Partnerships',
    department: 'Commercial Wholesale & Dealer Intake',
    avatar: '👨‍💼',
    status: 'active',
    currentTask: 'Auditing US & India B2B RFQs, vendor agency commissions & GSTIN tiers',
    tasksCompleted: 0,
    accuracy: 'B2B / MSA Check',
    skills: [
      'US & India Vendor Commission MSAs',
      'Volume Tier Discounting (up to 16%)',
      'Dealer GSTIN & US W-9 Onboarding',
      'Distributor Quote Generation',
    ],
    connectedUpstream: ['Maya Chen'],
    connectedDownstream: ['Rajesh Varma', 'Elena Rostova'],
    handshakeProtocol: 'B2B_DEALER_ORDER_INTAKE',
    businessValue:
      'Validates commercial B2B partner intake across US and India entities and routes vendor commission agreements to Legal.',
    systemPrompt:
      'You are Arjun Reddy, AI Head of B2B Wholesale & Vendor Partnerships for Radiant Spark LLC (USA) and RDNT Sparkle Industries LLP (India). You handle distributor onboarding, vendor agency commissions, and wholesale quotes.',
  },
  {
    id: 'emp-3',
    name: 'Sarah Jenkins',
    role: 'Global D2C CX Lead (US Stripe & ROSCA)',
    department: 'Consumer Retail & Subscription Commerce',
    avatar: '👩‍💻',
    status: 'active',
    currentTask: 'Operating Lifestyle Spark Stripe Checkout ($9.99 / $49.99 / $149.99) & US ROSCA consent',
    tasksCompleted: 0,
    accuracy: 'Stripe Hosted PCI',
    skills: [
      'Lifestyle Spark Stripe Subscriptions',
      'US FTC ROSCA Renewal Transparency',
      '9-Currency Live Card Localization',
      'D2C Customer Order Intake',
    ],
    connectedUpstream: ['Maya Chen'],
    connectedDownstream: ['Elena Rostova', 'Capt. Vikram Naidu'],
    handshakeProtocol: 'D2C_CART_CHECKOUT_EVENT',
    businessValue:
      'Routes Lifestyle Spark Stripe subscriptions and direct consumer orders with clear USD/global currency pricing and hosted PCI compliance.',
    systemPrompt:
      'You are Sarah Jenkins, Global D2C Customer Experience Lead for Radiant Spark LLC (USA). You manage Lifestyle Spark ($9.99/mo, $49.99 90-day pass, $149.99/yr) Stripe subscriptions and global customer support.',
  },
  {
    id: 'emp-4',
    name: 'Rajesh Varma',
    role: 'Director of Sparkle Drinks Requisitions & Bottling',
    department: 'Sparkle Drinks Manufacturing & Inventory',
    avatar: '👨‍🔬',
    status: 'active',
    currentTask: 'Allocating warehouse cases & raw material batch slips',
    tasksCompleted: 0,
    accuracy: 'Live Warehouse',
    skills: [
      'Batch Work Order Generation',
      'FSSAI Formulation Auditing',
      'Recyclable Aluminum Can Inventory Sync',
      'Botanical Extract Allocation',
    ],
    connectedUpstream: ['Arjun Reddy', 'Sarah Jenkins'],
    connectedDownstream: ['Elena Rostova', 'Priya Sharma'],
    handshakeProtocol: 'FACTORY_REQUISITION_WORK_ORDER',
    businessValue:
      'Deducts real SKU stock from persistent server inventory and assigns FSSAI bottling batch IDs.',
    systemPrompt:
      'You are Rajesh Varma, Director of Beverage Manufacturing & Inventory for Sparkle Drinks in Andhra Pradesh. You calculate botanical syrup, carbonation, and packaging requirements to generate production work orders.',
  },
  {
    id: 'emp-5',
    name: 'Elena Rostova',
    role: 'US-India Billing, Tax & GST Specialist',
    department: 'Corporate Finance & Tax Architecture',
    avatar: '👩‍⚖️',
    status: 'active',
    currentTask: 'Reconciling US W-9/1099-NEC affiliate tax rules & India 28% GST invoices',
    tasksCompleted: 0,
    accuracy: 'US Tax & GST',
    skills: [
      'US LLC W-9 / 1099-NEC Commission Accounting',
      'GST Tax Invoice Generation (HSN 22021010)',
      'Intra-State CGST/SGST & Inter-State IGST Split',
      'Live FX USD Equivalent Ledger',
    ],
    connectedUpstream: ['Rajesh Varma', 'Arjun Reddy'],
    connectedDownstream: ['Capt. Vikram Naidu', 'Marcus Vance'],
    handshakeProtocol: 'GST_INVOICE_EWAYBILL_STAMP',
    businessValue:
      'Computes deterministic US commission tax splits and India 28% statutory GST breakdowns with live FX conversion.',
    systemPrompt:
      'You are Elena Rostova, Chief Financial & Tax AI for Radiant Spark LLC (USA) and RDNT Sparkle Industries LLP (India). You manage US W-9/1099-NEC settlement math and Indian 28% GST tax invoices.',
  },
  {
    id: 'emp-6',
    name: 'Capt. Vikram Naidu',
    role: 'VP of Cold-Chain Logistics & Dispatch Fleet',
    department: 'Sparkle Distribution Network & Fleet Logistics',
    avatar: '👨‍✈️',
    status: 'active',
    currentTask: 'Generating sequential waybills & assigning route corridors',
    tasksCompleted: 0,
    accuracy: 'Route Planner',
    skills: [
      'Sequential Waybill Auto-Generation',
      'Corridor Transit Scheduling',
      'Cold-Chain Packing Specs',
      'Delivery City ETA Planning',
    ],
    connectedUpstream: ['Elena Rostova', 'Rajesh Varma'],
    connectedDownstream: ['Marcus Vance', 'Ananya Iyer'],
    handshakeProtocol: 'DISPATCH_WAYBILL_PLANNER',
    businessValue:
      'Generates sequential waybills and corridor dispatch manifests from Guntur hub to destination cities.',
    systemPrompt:
      'You are Captain Vikram Naidu, VP of Cold-Chain Fleet Logistics for Sparkle Distribution Network. You generate dispatch waybills and corridor plans from Guntur to destination cities.',
  },
  {
    id: 'emp-7',
    name: 'Priya Sharma',
    role: 'Raw Materials & Packaging Procurement Sentinel',
    department: 'Supply Chain & Vendor Relations',
    avatar: '👩‍🌾',
    status: 'active',
    currentTask: 'Monitoring SKU stock thresholds & flagging replenishment needs',
    tasksCompleted: 0,
    accuracy: 'Threshold Alert',
    skills: [
      'Stock Threshold Monitoring (<1,000 cases)',
      'Supplier RFQ Draft Generation',
      'Sustainable Can Packaging Specs',
      'Botanical Extract Scheduling',
    ],
    connectedUpstream: ['Rajesh Varma'],
    connectedDownstream: ['Elena Rostova', 'David Sterling'],
    handshakeProtocol: 'RAW_MATERIAL_PROCUREMENT_CHECK',
    businessValue:
      'Inspects remaining server inventory after every deduction and raises alerts when stock nears reorder thresholds.',
    systemPrompt:
      'You are Priya Sharma, AI Procurement Sentinel. You monitor aluminum can and botanical extract buffers so replenishment triggers before stockout.',
  },
  {
    id: 'emp-8',
    name: 'Marcus Vance',
    role: 'US Enterprise Cloud & API Engineer',
    department: 'Spark IT Consulting & Cloud Architecture',
    avatar: '👨‍💻',
    status: 'active',
    currentTask: 'Operating US Spark IT Consulting ERP webhooks, Stripe API & /api/deals/redirect',
    tasksCompleted: 0,
    accuracy: 'US Cloud API',
    skills: [
      'Oracle Cloud ERP & OIC Integration',
      'US Merchant Redirect Sanitation (/api/deals/redirect)',
      'Stripe Hosted Checkout & Firebase Auth',
      'Deterministic Trace ID Generation',
    ],
    connectedUpstream: ['Capt. Vikram Naidu', 'Elena Rostova'],
    connectedDownstream: ['David Sterling', 'Maya Chen'],
    handshakeProtocol: 'ORACLE_OIC_OR_LOCAL_LEDGER',
    businessValue:
      'Maintains Radiant Spark LLC cloud APIs, safe HTTP/HTTPS merchant redirects, Stripe webhook verification, and ERP webhooks.',
    systemPrompt:
      'You are Marcus Vance, Enterprise Systems AI Engineer at Spark IT Consulting (Radiant Spark LLC, USA). You persist verified ledgers and keep US cloud, Stripe, and SparkDeals redirect APIs healthy.',
  },
  {
    id: 'emp-9',
    name: 'Ananya Iyer',
    role: 'Dual US & India Legal Shield Sentinel',
    department: 'Corporate Legal Shield & Regulatory Auditing',
    avatar: '👩‍⚖️',
    status: 'active',
    currentTask: 'Auditing US FTC 16 CFR Part 255, Amazon/Walmart/Best Buy shields, DMCA § 512 & India FSSAI',
    tasksCompleted: 0,
    accuracy: 'US + India Rule',
    skills: [
      'US FTC 16 CFR Part 255 & ROSCA Disclosures',
      'Amazon.com / Walmart / Best Buy Merchant Boundaries',
      'DMCA 17 U.S.C. § 512 & Section 230 Alignment',
      'India Sec 79 IT Act & FSSAI Compliance',
    ],
    connectedUpstream: ['Elena Rostova', 'Capt. Vikram Naidu'],
    connectedDownstream: ['Maya Chen', 'David Sterling'],
    handshakeProtocol: 'STATUTORY_LEGAL_SHIELD_AUDIT',
    businessValue:
      'Maintains transparent US retail affiliate disclaimers (Amazon, Walmart, Best Buy, Target), written SOW/MSA boundaries, DMCA takedowns, and India statutory compliance.',
    systemPrompt:
      'You are Ananya Iyer, Chief US & India Legal Compliance Sentinel for Radiant Spark LLC (USA) and RDNT Sparkle Industries LLP (India). You enforce FTC 16 CFR Part 255 disclosures, Amazon Associates 6-hour price freshness rules, Walmart/Best Buy external merchant boundaries, ROSCA subscription clarity, DMCA takedown workflows, and Indian GST/FSSAI rules without claiming false lawsuit immunity.',
  },
  {
    id: 'emp-10',
    name: 'David Sterling',
    role: 'Chief Revenue & Global Market Strategist (USD & INR)',
    department: 'Business Intelligence & Worldwide Scaling',
    avatar: '📈',
    status: 'active',
    currentTask: 'Reconciling US Affiliate/Stripe (USD) & India ERP Revenue at live ECB spot rates',
    tasksCompleted: 0,
    accuracy: 'Live FX Margin',
    skills: [
      'US Affiliate & Stripe USD Reconciliation',
      'Live Spot FX USD/INR Settlement',
      'Real-Time Ledger Rollups',
      'Cross-Border Tax-Adjusted Net Math',
    ],
    connectedUpstream: ['Marcus Vance', 'Priya Sharma'],
    connectedDownstream: ['Maya Chen'],
    handshakeProtocol: 'REVENUE_FX_SETTLEMENT_ROLLUP',
    businessValue:
      'Converts real verified Amazon/Walmart/Best Buy postbacks, Stripe subscriptions, and ERP invoices into unified USD/INR revenue.',
    systemPrompt:
      'You are David Sterling, Chief Revenue Strategist for Radiant Spark LLC (USA) & RDNT Sparkle Industries LLP (India). You reconcile verified USD and INR revenue streams with zero fabricated figures.',
  },
  {
    id: 'emp-11',
    name: 'Kavya Nair',
    role: 'US & Global Affiliate Monetization Architect',
    department: 'Affiliate Commerce & Merchant Attribution',
    avatar: '💎',
    status: 'active',
    currentTask: 'Tagging Amazon.com, Walmart, Best Buy, Target, Home Depot & eBay deals cleanly',
    tasksCompleted: 0,
    accuracy: 'US Retail Links',
    skills: [
      'Amazon Associates US & Walmart Impact Tagging',
      'Best Buy Impact / eBay EPN / Skimlinks / Sovrn',
      'Server Redirect Click Attribution (/api/deals/redirect)',
      'Zero-Fake Commission Postback Reconciliation',
    ],
    connectedUpstream: ['Maya Chen', 'Ananya Iyer'],
    connectedDownstream: ['David Sterling', 'Marcus Vance'],
    handshakeProtocol: 'SPARKDEALS_AFFILIATE_ATTRIBUTION',
    businessValue:
      'Routes SparkDeals links directly to US merchants (Amazon.com, Walmart, Best Buy, Target, Newegg, Costco, eBay), injects partner tags, and logs click attribution.',
    systemPrompt:
      'You are Kavya Nair, SparkDeals Affiliate Monetization Architect at Radiant Spark LLC (USA). You inspect SparkDeals offers for Amazon.com, Walmart, Best Buy, Target, Home Depot, Newegg, Costco, and eBay to unwrap aggregator redirects into direct merchant links and verify click & postback attribution.',
  },
];

export interface SparkleDrinkProduct {
  id: string;
  name: string;
  tagline: string;
  caseSize: string;
  casePrice: number;
  canPrice: number;
  hsnCode: string;
  fssaiLicense: string;
  image: string;
  inStockCases: number;
}

export const SPARKLE_DRINKS_PRODUCTS: SparkleDrinkProduct[] = [
  {
    id: 'drk-1',
    name: 'Sparkle Refresh — Botanical Berry Spritz',
    tagline: 'Zero Refined Sugar · Organic Blueberry & Acai Infusion',
    caseSize: '24 x 330ml Aluminum Cans',
    casePrice: 1440,
    canPrice: 60,
    hsnCode: '22021010',
    fssaiLicense: 'FSSAI Lic. #10126999000142',
    image: '/sparkle-drinks.jpg',
    inStockCases: 4850,
  },
  {
    id: 'drk-2',
    name: 'Sparkle Refresh — Citrus Herbal Tonic',
    tagline: 'Kaffir Lime, Lemongrass & Electrolyte Spring Minerals',
    caseSize: '24 x 330ml Aluminum Cans',
    casePrice: 1440,
    canPrice: 60,
    hsnCode: '22021010',
    fssaiLicense: 'FSSAI Lic. #10126999000142',
    image: '/sparkle-drinks.jpg',
    inStockCases: 3920,
  },
  {
    id: 'drk-3',
    name: 'Sparkle Refresh — Ginger Mint Sparkler',
    tagline: 'Cold-Pressed Guntur Ginger & Fresh Spearmint Botanicals',
    caseSize: '24 x 330ml Aluminum Cans',
    casePrice: 1440,
    canPrice: 60,
    hsnCode: '22021010',
    fssaiLicense: 'FSSAI Lic. #10126999000142',
    image: '/sparkle-drinks.jpg',
    inStockCases: 5100,
  },
  {
    id: 'drk-4',
    name: 'Sparkle Hydrate — Active Electrolyte Fusion',
    tagline: 'Zero Calorie · Himalayan Pink Salt & Coconut Water Essence',
    caseSize: '24 x 330ml Aluminum Cans',
    casePrice: 1560,
    canPrice: 65,
    hsnCode: '22021010',
    fssaiLicense: 'FSSAI Lic. #10126999000142',
    image: '/sparkle-drinks.jpg',
    inStockCases: 4200,
  },
];

// Starts empty; hydrated live from persistent server store (/api/brain/status)
export const INITIAL_ORDERS: SparkDrinkOrder[] = [];
