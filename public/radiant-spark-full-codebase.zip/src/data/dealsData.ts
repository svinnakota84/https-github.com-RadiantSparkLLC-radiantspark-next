/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { DealItem } from '../types';

// Intentionally empty: SparkDeals renders exclusively from live RSS/store synchronization (/api/deals & /deals-feed.json).
export const INITIAL_DEALS: DealItem[] = [];
